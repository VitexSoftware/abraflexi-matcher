<?php

/**
 * Incoming Invoice Matcher
 *
 * @author     Vítězslav Dvořák <vitex@arachne.cz>
 * @copyright (c) 2018, Vítězslav Dvořák
 */

namespace AbraFlexi\Matcher;

/**
 * Description of InvoicePayment
 *
 * @author vitex
 */
class IncomingInvoice extends \AbraFlexi\Bricks\ParovacFaktur {
    //put your code here
}
